function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5kfqHR3wfPC":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

